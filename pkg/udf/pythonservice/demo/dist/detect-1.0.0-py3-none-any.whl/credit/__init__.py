# coding = utf-8
# -*- coding:utf-8 -*-
from .detection import detect
