declare module "node-gyp-build";
