# USearch for Wolfram

## Installation

```txt
https://github.com/unum-cloud/usearch
```

## Quickstart

```wolfram

```
