==============
C# SDK
==============


.. mdinclude:: ../../csharp/README.md
