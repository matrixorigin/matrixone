# StringZilla Scripts

This directory contains benchmarks, tests, and exploratory scripts for the StringZilla library, focused on internal functionality, rather than third-party alternatives.
For comparative analysis, please refer to [StringWa.rs](https://github.com/ashvardanian/StringWa.rs/).
