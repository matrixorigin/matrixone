/**
 *  @file       test.cpp
 *  @author     Ash Vardanian
 *  @brief      Unit-testing vector-search functionality.
 *  @date       June 10, 2023
 *
 *
 *  Key and slot types:
 *      - 64-bit `std::int64_t` keys and `std::uint32_t` slots are most popular.
 *      - 64-bit `std::uint64_t` keys and `std::uint40_t` are most space-efficient for
 *        point clouds 4B+ in size.
 *      - 128-bit `uuid_t` keys and `enum slot64_t : std::uint64_t` make most sense for
 *        for database users, implementing portable, concurrent systems.
 */
#include <cassert> // `assert`
#include <cmath>   // `std::abs`
#include <csignal> // `std::signal`, `SIGSEGV`, ...
#include <cstdio>  // `std::fprintf`
#include <cstdlib> // `std::_Exit`
#include <limits>  // `std::numeric_limits`

#include <algorithm>     // `std::shuffle`
#include <random>        // `std::default_random_engine`
#include <stdexcept>     // `std::terminate`
#include <unordered_map> // `std::unordered_map`
#include <vector>        // `std::vector`

// Back-trace support. Prefer the C++23 `<stacktrace>` library when the
// toolchain + stdlib expose it (`__cpp_lib_stacktrace`); otherwise fall back
// to the OS-native facility so that unit-test crashes in CI log something
// useful beyond a bare exit code.
#if defined(__has_include)
#if __has_include(<stacktrace>)
#include <stacktrace>
#endif
#endif
#if defined(__cpp_lib_stacktrace) && __cpp_lib_stacktrace >= 202011L
#define USEARCH_HAS_STD_STACKTRACE 1
#else
#define USEARCH_HAS_STD_STACKTRACE 0
#if defined(_WIN32)
// `windows.h` must precede `dbghelp.h` — the latter uses `PSTR` and friends
// that are only defined after `windows.h`. The blank line keeps clang-format
// from re-sorting the two headers into a single alphabetized block.
#include <windows.h>

#include <dbghelp.h>
#pragma comment(lib, "Dbghelp.lib")
#else
#include <execinfo.h>
#include <unistd.h>
#endif
#endif

#define SZ_USE_X86_AVX512 0            // Sanitizers hate AVX512
#include <stringzilla/stringzilla.hpp> // Levenshtein distance implementation

#include <usearch/index.hpp>
#include <usearch/index_dense.hpp>
#include <usearch/index_plugins.hpp>

using namespace unum::usearch;
using namespace unum;

void __expect(bool must_be_true, char const* file, int line, char const* message = nullptr) {
    if (must_be_true)
        return;
    message = message ? message : "C++ unit test failed";
    char buffer[512];
    std::snprintf(buffer, sizeof(buffer), "%s at %s:%d", message, file, line);
    usearch_raise_runtime_error(buffer);
}

template <typename value_at>
void __expect_eq(value_at a, value_at b, char const* file, int line, char const* message = nullptr) {
    __expect(a == b, file, line, message);
}

#define expect(cond) __expect((bool)(cond), __FILE__, __LINE__)
#define expect_eq(a, b) __expect_eq<decltype(a)>((a), (b), __FILE__, __LINE__)

/**
 *  Less error-prone type definition to differentiate `std::uint32_t` and other native
 *  types in logs and avoid implicit conversions.
 */
enum slot32_t : std::uint32_t {};
template <> struct unum::usearch::hash_gt<slot32_t> : public unum::usearch::hash_gt<std::uint32_t> {};
template <> struct unum::usearch::default_free_value_gt<slot32_t> {
    static slot32_t value() noexcept { return static_cast<slot32_t>((std::numeric_limits<std::uint32_t>::max)()); }
};

/*
 *  Let's instantiate several templates to make all of their symbols available for testing.
 *  https://dhashe.com/how-to-build-highly-debuggable-c-binaries.html
 */
template class unum::usearch::index_gt<float, std::int64_t, slot32_t>;
template class unum::usearch::index_gt<float, std::int64_t, uint40_t>;
template class unum::usearch::index_dense_gt<std::int64_t, slot32_t>;
template class unum::usearch::index_dense_gt<std::int64_t, uint40_t>;

/**
 *  @brief  Convenience wrapper combining combined allocation and construction of an index.
 */
template <typename index_at> struct aligned_wrapper_gt {
    using index_t = index_at;
    using alloc_t = aligned_allocator_gt<index_t, 64>;

    alloc_t alloc;
    index_t* index = nullptr;

    template <typename... args_at> aligned_wrapper_gt(args_at&&... args) {

        alloc_t index_alloc;
        index_t* index_typed = index_alloc.allocate(1);
        expect(index_typed != nullptr);
        expect(((unsigned long long)(index_typed) % 64ull) == 0ull);

        new (index_typed) index_t(std::forward<args_at>(args)...);
        index = index_typed;
    }

    ~aligned_wrapper_gt() {
        if (index != nullptr) {
            index->~index_t();
            alloc.deallocate(index, 1);
        }
    }
};

/**
 * Tests the functionality of the custom uint40_t type ensuring consistent
 * behavior across various constructors from uint32_t, uint64_t, and size_t types,
 * and validates the relational ordering between various values.
 */
void test_uint40() {

    union uint64_octets_t {
        std::uint64_t value;
        std::uint8_t octets[8];
    };

    // Constants for tests
    std::uint64_t max_uint40_k = (1ULL << 40) - 1;

    // Set of test numbers
    std::vector<std::uint64_t> test_numbers = {
        42ull,            // Typical small number
        4242ull,          // Larger number still within uint40 range
        (1ull << 39),     // A high number within range
        (1ull << 40) - 1, // Maximum value representable in uint40
        1ull << 40,       // Exactly at the boundary of uint40
        (1ull << 40) + 1, // Just beyond the boundary of uint40
        1ull << 63        // Well beyond the uint40 boundary, tests masking
    };

    for (std::uint64_t input_u64 : test_numbers) {
        std::uint32_t input_u32 = static_cast<std::uint32_t>(input_u64);
        std::size_t input_size = static_cast<std::size_t>(input_u64);

        // Create uint40_t instances from different types
        uint40_t u40_from_u32(input_u32);
        uint40_t u40_from_u64(input_u64);
        uint40_t u40_from_size(input_size);

        // Expected value after masking
        uint64_octets_t input_clamped;
        input_clamped.value = input_u64 & max_uint40_k;

        // Check if all conversions are equal to the masked value
        expect_eq(u40_from_u32, input_clamped.value & 0xFFFFFFFF);
        expect_eq(u40_from_u64, input_clamped.value);
        expect_eq(u40_from_size, input_clamped.value);

        // Check relative ordering against all other test numbers
        for (std::uint64_t other_u64 : test_numbers) {
            uint64_octets_t other_clamped;
            other_clamped.value = other_u64 & max_uint40_k;
            uint40_t other_u40(other_clamped.value);

            // Check < and >
            expect_eq(input_clamped.value < other_clamped.value, u40_from_u64 < other_u40);
            expect_eq(input_clamped.value > other_clamped.value, u40_from_u64 > other_u40);

            // Check <= and >=
            expect_eq(input_clamped.value <= other_clamped.value, u40_from_u64 <= other_u40);
            expect_eq(input_clamped.value >= other_clamped.value, u40_from_u64 >= other_u40);
        }
    }

    // Test equality and inequality operators
    for (std::uint64_t input_u64 : test_numbers) {
        uint64_octets_t input_clamped;
        input_clamped.value = input_u64 & max_uint40_k;
        uint40_t u40(input_clamped.value);

        expect_eq(u40 == uint40_t(input_clamped.value), true);
        expect_eq(u40 != uint40_t(input_clamped.value + 1), true);
    }

    // Test min and max functions
    expect_eq((uint40_t::min)(), uint40_t(0u));
    expect_eq((uint40_t::max)(), uint40_t(max_uint40_k));

    // Test copy and move semantics
    for (std::uint64_t input_u64 : test_numbers) {
        uint40_t u40_orig(input_u64);

        uint40_t u40_copy(u40_orig);
        expect_eq(u40_orig, u40_copy);

        uint40_t u40_move(std::move(u40_orig));
        expect_eq(u40_copy, u40_move);
    }

    // Test default constructor (zero initialization)
    uint40_t u40_default;
    expect_eq(u40_default, uint40_t(0u));
}

void test_checked_size_arithmetic() {

    std::printf("Testing checked size arithmetic\n");
    std::size_t max = (std::numeric_limits<std::size_t>::max)();

    checked_size_result_t cast = checked_size_from_u64(42);
    expect(cast);
    expect_eq(cast.value, static_cast<std::size_t>(42));
    if (sizeof(std::size_t) < sizeof(std::uint64_t))
        expect(!checked_size_from_u64((std::numeric_limits<std::uint64_t>::max)()));

    checked_size_result_t sum = checked_add(max - 1, 1);
    expect(sum);
    expect_eq(sum.value, max);
    expect(!checked_add(max, 1));

    checked_size_result_t product = checked_mul(max / 2, 2);
    expect(product);
    expect_eq(product.value, max - 1);
    expect(!checked_mul(max / 2 + 1, 2));

    checked_size_result_t fused = checked_mul_add(10, 20, 30);
    expect(fused);
    expect_eq(fused.value, static_cast<std::size_t>(230));
    expect(!checked_mul_add(max / 2 + 1, 2, 0));
    expect(!checked_mul_add(max / 2, 2, 2));

    checked_size_result_t rounded = checked_round_up(17, 8);
    expect(rounded);
    expect_eq(rounded.value, static_cast<std::size_t>(24));
    expect(!checked_round_up(max, 8));

    checked_size_result_t power = checked_ceil2(17);
    expect(power);
    expect_eq(power.value, static_cast<std::size_t>(32));
    checked_size_result_t zero_power = checked_ceil2(0);
    expect(zero_power);
    expect_eq(zero_power.value, static_cast<std::size_t>(0));
    expect(!checked_ceil2(max));
}

/**
 *  @brief  Tests the functionality of the custom float16_t type ensuring consistent.
 */
void test_float16() {}

/**
 * The goal of this test is to invoke as many different interfaces as possible, making sure that all code-paths compile.
 * For that it only uses a tiny set of 3 predefined vectors.
 *
 * @param index Reference to the index where vectors will be stored and searched.
 * @param vectors A collection of vectors to be tested.
 * @param args Additional arguments for configuring search or index operations.
 * @tparam punned_ak Template parameter that determines specific behaviors or checks in the test based on its value.
 * @tparam index_at Type of the index being tested.
 * @tparam scalar_at Data type of the elements in the vectors.
 * @tparam extra_args_at Variadic template parameter types for additional configuration.
 */
template <bool punned_ak, typename index_at, typename scalar_at, typename... extra_args_at>
void test_minimal_three_vectors(index_at& index, //
                                typename index_at::vector_key_t key_first, std::vector<scalar_at> const& vector_first,
                                typename index_at::vector_key_t key_second, std::vector<scalar_at> const& vector_second,
                                typename index_at::vector_key_t key_third, std::vector<scalar_at> const& vector_third,
                                extra_args_at&&... args) {

    using scalar_t = scalar_at;
    using index_t = index_at;
    using vector_key_t = typename index_t::vector_key_t;
    using distance_t = typename index_t::distance_t;

    // Try checking the empty state
    if constexpr (punned_ak) {
        if (index.config().enable_key_lookups) {
            expect(!index.contains(key_first));
            expect(!index.get(key_first, (f32_t*)nullptr, 1));
        }
    }

    // Add data
    expect(index.try_reserve(10));
    expect(index.add(key_first, vector_first.data(), args...));

    // Default approximate search
    vector_key_t matched_keys[10] = {0};
    distance_t matched_distances[10] = {0};
    std::size_t matched_count = index.search(vector_first.data(), 5, args...).dump_to(matched_keys, matched_distances);

    expect(matched_count == 1);
    expect(matched_keys[0] == key_first);
    expect(std::abs(matched_distances[0]) < 0.01);

    // Add more entries
    index.add(key_second, vector_second.data(), args...);
    index.add(key_third, vector_third.data(), args...);
    expect(index.size() == 3);

    // Perform single entry search
    {
        auto search_result = index.search(vector_first.data(), 5, args...);
        expect(search_result);
        matched_count = search_result.dump_to(matched_keys, matched_distances);
        expect(matched_count != 0);
    }

    // Perform filtered exact search, keeping only odd values
    if constexpr (punned_ak) {
        auto is_odd = [](vector_key_t key) -> bool { return (key & 1) != 0; };
        auto search_result = index.filtered_search(vector_first.data(), 5, is_odd, args...);
        expect(search_result);
        matched_count = search_result.dump_to(matched_keys, matched_distances);
        expect(matched_count != 0);
        for (std::size_t i = 0; i < matched_count; i++)
            expect(is_odd(matched_keys[i]));
    }

    // Validate scans
    std::size_t count = 0;
    for (auto member : index) {
        vector_key_t id = member.key;
        expect(id >= key_first && id <= key_third);
        count++;
    }
    expect((count == 3));
    expect((index.stats(0).nodes == 3));

    // Check if clustering endpoint compiles
    index.cluster(vector_first.data(), 0, args...);

    // Try removals and replacements
    if constexpr (punned_ak) {
        if (index.config().enable_key_lookups) {
            using labeling_result_t = typename index_t::labeling_result_t;
            labeling_result_t result = index.remove(key_third);
            expect(result);
            expect(index.size() == 2);
            index.add(key_third, vector_third.data(), args...);
            expect(index.size() == 3);
        }
    }

    expect(index.save("tmp.usearch"));

    // Perform content and scan validations for a copy
    {
        auto copy_result = index.copy();
        expect(copy_result);
        index_at copied_index = std::move(copy_result.index);

        // Perform single entry search
        auto search_result = copied_index.search(vector_first.data(), 5, args...);
        expect(search_result);
        matched_count = search_result.dump_to(matched_keys, matched_distances);
        expect(matched_count != 0);

        // Validate scans
        std::size_t count = 0;
        for (auto member : copied_index) {
            vector_key_t id = member.key;
            expect(id >= key_first && id <= key_third);
            count++;
        }
        expect_eq(count, 3);
        expect_eq(copied_index.stats(0).nodes, 3);
    }

    // Perform content and scan validations for a moved
    {
        index_at moved_index(std::move(index));

        // Perform single entry search
        auto search_result = moved_index.search(vector_first.data(), 5, args...);
        expect(search_result);
        matched_count = search_result.dump_to(matched_keys, matched_distances);
        expect(matched_count != 0);

        // Validate scans
        std::size_t count = 0;
        for (auto member : moved_index) {
            vector_key_t id = member.key;
            expect(id >= key_first && id <= key_third);
            count++;
        }
        expect_eq(count, 3);
        expect_eq(moved_index.stats(0).nodes, 3);
    }

    // Check if metadata is retrieved correctly
    if constexpr (punned_ak) {
        auto head_result = index_dense_metadata_from_path("tmp.usearch");
        expect(head_result);
        expect_eq(3ull, head_result.head.count_present);
    }

    // Try loading and move assignment
    {
        index_at loaded_index;
        auto load_result = loaded_index.load("tmp.usearch");
        expect(load_result);
        index = std::move(loaded_index);
    }

    // Check the copy of the restored index
    {
        auto copy_result = index.copy();
        expect(copy_result);
        index_at copied_index = std::move(copy_result.index);
        expect_eq(copied_index.size(), 3);
    }

    // Search again over reconstructed index
    {
        matched_count = index.search(vector_first.data(), 5, args...).dump_to(matched_keys, matched_distances);
        expect_eq(matched_count, 3);
        expect_eq(matched_keys[0], key_first);
        expect(std::abs(matched_distances[0]) < 0.01);
    }

    // Try retrieving a vector from a deserialized index
    if constexpr (punned_ak) {
        if (index.config().enable_key_lookups) {
            std::size_t dimensions = vector_first.size();
            std::vector<scalar_t> vector_reloaded(dimensions);
            expect(index.get(key_second, vector_reloaded.data()));
            expect(std::equal(vector_second.data(), vector_second.data() + dimensions, vector_reloaded.data()));
        }
    }
}

/**
 *  @brief  Tests value removals, by repeatedly adding and removing a couple of vectors.
 *
 *  @param index Reference to the index where vectors will be stored and searched.
 *  @param vector_first First vector to be tested.
 *  @param vector_second Second vector to be tested.
 *  @param args Additional arguments for configuring search or index operations.
 */
template <typename index_at, typename scalar_at>
void test_punned_add_remove_vector(             //
    index_at& index,                            //
    std::vector<scalar_at> const& vector_first, //
    std::vector<scalar_at> const& vector_second) {

    using index_t = index_at;
    using vector_key_t = typename index_t::vector_key_t;

    // Creating the index
    expect(index.try_reserve(10));
    expect(index.capacity() >= 10);

    // Max 64-bit unsigned key value is: 18446744073709551615
    vector_key_t key_first = 483367403120493160;
    vector_key_t key_second = 483367403120558696;
    vector_key_t key_third = 483367403120624232;
    vector_key_t key_fourth = 483367403120624233;

    // Adding, getting, and removing vectors
    expect(index.add(key_first, vector_first.data()));
    std::vector<float> found_slice(vector_first.size(), 0.0f);
    expect_eq(index.get(key_first, found_slice.data()), 1);
    expect(index.remove(key_first));

    expect(index.add(key_second, vector_second.data()));
    expect_eq(index.get(key_second, found_slice.data()), 1);
    expect(index.remove(key_second));

    expect(index.add(key_third, vector_second.data()));
    expect_eq(index.get(key_third, found_slice.data()), 1);
    expect(index.remove(key_third));

    expect(index.add(key_fourth, vector_second.data()));
    expect_eq(index.get(key_fourth, found_slice.data()), 1);
    expect(index.remove(key_fourth));

    expect_eq(index.size(), 0);
}

/**
 * Tests the normal operational mode of the library, dealing with a variable length collection
 * of `vectors` with monotonically increasing keys starting from `start_key`.
 *
 * @param index Reference to the index where vectors will be stored and searched.
 * @param start_key The key for the first `vector`, others are generated with increments.
 * @param vectors A collection of vectors to be tested.
 * @param args Additional arguments for configuring search or index operations.
 * @tparam punned_ak Template parameter that determines specific behaviors or checks in the test based on its value.
 * @tparam index_at Type of the index being tested.
 * @tparam scalar_at Data type of the elements in the vectors.
 * @tparam extra_args_at Variadic template parameter types for additional configuration.
 */
template <bool punned_ak, typename index_at, typename scalar_at, typename... extra_args_at>
void test_collection(index_at& index, typename index_at::vector_key_t const start_key,
                     std::vector<std::vector<scalar_at>> const& vectors, extra_args_at&&... args) {

    using scalar_t = scalar_at;
    using index_t = index_at;
    using vector_key_t = typename index_t::vector_key_t;
    using distance_t = typename index_t::distance_t;
    using index_add_result_t = typename index_t::add_result_t;
    using index_search_result_t = typename index_t::search_result_t;

    // Generate some keys starting from end,
    // for three vectors from the dataset
    vector_key_t const key_first = start_key;
    std::vector<scalar_at> const& vector_first = vectors[0];
    std::size_t dimensions = vector_first.size();

    // Try batch requests, heavily over-subscribing the CPU cores
    std::size_t executor_threads = std::thread::hardware_concurrency();
    executor_default_t executor(executor_threads);
    expect(index.try_reserve({vectors.size(), executor.size()}));
    executor.fixed(vectors.size(), [&](std::size_t thread, std::size_t task) {
        if constexpr (punned_ak) {
            index_add_result_t result = index.add(start_key + task, vectors[task].data(), args...);
            expect(result);
        } else {
            index_update_config_t config;
            config.thread = thread;
            index_add_result_t result = index.add(start_key + task, vectors[task].data(), args..., config);
            expect(result);
        }
    });

    // Make sure we didn't lose parallelism settings after reload
    expect(index.limits().threads_search >= executor.size());
    if constexpr (punned_ak)
        expect(index.currently_available_threads() >= executor.size());

    // Parallel search over the same vectors
    executor.fixed(vectors.size(), [&](std::size_t thread, std::size_t task) {
        std::size_t max_possible_matches = vectors.size();
        std::size_t count_requested = max_possible_matches;
        std::vector<vector_key_t> matched_keys(count_requested);
        std::vector<distance_t> matched_distances(count_requested);
        std::size_t matched_count = 0;

        // Invoke the search kernel
        if constexpr (punned_ak) {
            index_search_result_t result = index.search(vectors[task].data(), count_requested, args...);
            expect(result);
            matched_count = result.dump_to(matched_keys.data(), matched_distances.data());
        } else {
            index_search_config_t config;
            config.thread = thread;
            index_search_result_t result = index.search(vectors[task].data(), count_requested, args..., config);
            expect(result);
            matched_count = result.dump_to(matched_keys.data(), matched_distances.data());
        }

        // In approximate search we can't always expect the right answer to be found
        //      expect_eq(matched_count, max_possible_matches);
        //      expect_eq(matched_keys[0], start_key + task);
        //      expect(std::abs(matched_distances[0]) < 0.01);
        expect(matched_count <= max_possible_matches);

        // Check that all the distance are monotonically rising
        for (std::size_t i = 1; i < matched_count; i++)
            expect(matched_distances[i - 1] <= matched_distances[i]);
    });

    // Search again over mapped index
    expect(index.save("tmp.usearch"));

    {
        auto copy_result = index.copy();
        expect(copy_result);
        index_at copied_index = std::move(copy_result.index);
        expect_eq(copied_index.size(), vectors.size());
    }

    // Check for duplicates
    if constexpr (punned_ak) {
        if (index.config().enable_key_lookups) {
            expect(index.try_reserve({vectors.size() + 1u, executor.size()}));
            index_add_result_t result = index.add(key_first, vector_first.data(), args...);
            expect_eq(!!result, index.multi());
            result.error.release();

            std::size_t first_key_count = index.count(key_first);
            expect_eq(first_key_count, 1ul + index.multi());
        }
    }

    // Recover the state before the duplicate insertion
    expect(index.view("tmp.usearch"));

    // Parallel search over the same vectors
    executor.fixed(vectors.size(), [&](std::size_t thread, std::size_t task) {
        // Check over-sampling beyond the size of the collection
        std::size_t max_possible_matches = vectors.size();
        std::size_t count_requested = max_possible_matches * 10;
        std::vector<vector_key_t> matched_keys(count_requested);
        std::vector<distance_t> matched_distances(count_requested);
        std::size_t matched_count = 0;

        // Invoke the search kernel
        if constexpr (punned_ak) {
            index_search_result_t result = index.search(vectors[task].data(), count_requested, args...);
            expect(result);
            matched_count = result.dump_to(matched_keys.data(), matched_distances.data());
        } else {
            index_search_config_t config;
            config.thread = thread;
            index_search_result_t result = index.search(vectors[task].data(), count_requested, args..., config);
            expect(result);
            matched_count = result.dump_to(matched_keys.data(), matched_distances.data());
        }

        // In approximate search we can't always expect the right answer to be found
        //      expect_eq(matched_count, max_possible_matches);
        //      expect_eq(matched_keys[0], start_key + task);
        //      expect(std::abs(matched_distances[0]) < 0.01);
        expect(matched_count <= max_possible_matches);

        // Check that all the distance are monotonically rising
        for (std::size_t i = 1; i < matched_count; i++)
            expect(matched_distances[i - 1] <= matched_distances[i]);
    });

    // Try retrieving a vector from a deserialized index
    if constexpr (punned_ak) {
        if (index.config().enable_key_lookups) {
            expect(index.contains(key_first));
            expect_eq(index.count(key_first), 1);
            std::vector<scalar_t> vector_reloaded(dimensions);
            index.get(key_first, vector_reloaded.data());
            expect(std::equal(vector_first.data(), vector_first.data() + dimensions, vector_reloaded.data()));
        }

        auto compaction_result = index.compact();
        expect(compaction_result);
    }

    expect(index.memory_usage() > 0);
    expect(index.stats().max_edges > 0);

    // Check metadata
    if constexpr (punned_ak) {
        index_dense_metadata_result_t meta = index_dense_metadata_from_path("tmp.usearch");
        expect(meta);
    }
}

/**
 * Stress-tests the behavior of the type-punned higher-level index under heavy concurrent insertions,
 * removals and updates.
 *
 * @param index Reference to the index where vectors will be stored and searched.
 * @param start_key The key for the first `vector`, others are generated with increments.
 * @param vectors A collection of vectors to be tested.
 * @param executor_threads Number of threads to be used for concurrent operations.
 * @tparam punned_ak Template parameter that determines specific behaviors or checks in the test based on its value.
 * @tparam index_at Type of the index being tested.
 * @tparam scalar_at Data type of the elements in the vectors.
 * @tparam extra_args_at Variadic template parameter types for additional configuration.
 */
template <typename index_at, typename scalar_at, typename... extra_args_at>
void test_punned_concurrent_updates(index_at& index, typename index_at::vector_key_t const start_key,
                                    std::vector<std::vector<scalar_at>> const& vectors, std::size_t executor_threads) {

    using index_t = index_at;

    // Try batch requests, heavily oversubscribing the CPU cores
    executor_default_t executor(executor_threads);
    expect(index.try_reserve({vectors.size(), executor.size()}));
    executor.fixed(vectors.size(), [&](std::size_t, std::size_t task) {
        using add_result_t = typename index_t::add_result_t;
        add_result_t result = index.add(start_key + task, vectors[task].data());
        expect(result);
    });
    expect_eq(index.size(), vectors.size());

    // Without key lookups we can't do much more
    if (!index.config().enable_key_lookups)
        return;

    // Remove all the keys
    executor.fixed(vectors.size(), [&](std::size_t, std::size_t task) {
        using labeling_result_t = typename index_t::labeling_result_t;
        labeling_result_t result = index.remove(start_key + task);
        expect(result);
    });
    expect_eq(index.size(), 0);

    // Add them back, which under the hood will trigger the `update`
    executor.fixed(vectors.size(), [&](std::size_t, std::size_t task) {
        using add_result_t = typename index_t::add_result_t;
        add_result_t result = index.add(start_key + task, vectors[task].data());
        expect(result);
    });
    expect_eq(index.size(), vectors.size());
}

/**
 * Regression test for USearch #735: concurrent `add()` must never leave a node
 * stored-but-unreachable. The bug: while a node was building links top-down, its
 * per-level lock was released between levels, so a concurrent inserter could
 * descend onto it before its lower level had any links, dead-end the level search,
 * and end up attached by a single fragile edge that was then evicted — leaving a
 * node for which `contains()` is true but `search()` can never reach it.
 *
 * This builds an index from many threads, then asserts every inserted vector finds
 * itself in an exhaustive search. A single orphaned node fails the test. Before the
 * fix this reproduced a handful of unreachable nodes per run at a few thousand
 * vectors; with serialized (single-thread) builds it always passed — so the test is
 * only meaningful with `threads_count > 1`.
 *
 * @param dimensions Number of dimensions per vector.
 * @param vectors_per_thread Vectors inserted by each worker thread.
 * @param threads_count Number of concurrent insertion threads (must be > 1 to bite).
 * @param connectivity Graph connectivity (M) for the index.
 */
template <typename key_at, typename slot_at>
void test_concurrent_add_reachability(std::size_t dimensions, std::size_t vectors_per_thread,
                                      std::size_t threads_count, std::size_t connectivity) {

    using index_t = index_dense_gt<key_at, slot_at>;
    std::size_t const total = vectors_per_thread * threads_count;

    // Deterministic pseudo-random vectors, so a failure is reproducible.
    std::vector<std::vector<float>> vectors(total);
    std::default_random_engine generator(42);
    std::uniform_real_distribution<float> distribution(-1.0f, 1.0f);
    for (auto& vector : vectors) {
        vector.resize(dimensions);
        for (auto& component : vector)
            component = distribution(generator);
    }

    metric_punned_t metric(dimensions, metric_kind_t::cos_k, scalar_kind_t::f32_k);
    index_dense_config_t config(connectivity);
    typename index_t::state_result_t make_result = index_t::make(metric, config);
    expect(make_result);
    index_t& index = make_result.index;

    // Concurrent build — the condition that triggers #735.
    executor_default_t executor(threads_count);
    expect(index.try_reserve({total, executor.size()}));
    executor.fixed(total, [&](std::size_t thread, std::size_t task) {
        typename index_t::add_result_t result = index.add(static_cast<key_at>(task), vectors[task].data(), thread);
        expect(result);
    });
    expect_eq(index.size(), total);

    // Every stored vector must be reachable: searching for it (requesting every
    // result) must return itself. An orphaned node is contained but unreachable.
    std::size_t unreachable = 0;
    std::vector<key_at> keys(total);
    std::vector<distance_punned_t> distances(total);
    for (std::size_t i = 0; i != total; ++i) {
        typename index_t::search_result_t search_result = index.search(vectors[i].data(), total);
        expect(search_result);
        std::size_t found = search_result.dump_to(keys.data(), distances.data());
        bool found_self = false;
        for (std::size_t r = 0; r != found && !found_self; ++r)
            found_self = keys[r] == static_cast<key_at>(i);
        unreachable += !found_self;
    }
    expect_eq(unreachable, static_cast<std::size_t>(0));
}

/**
 * Overloaded function to test cosine similarity index functionality using specific scalar, key, and slot types.
 *
 * This function initializes vectors and an index instance to test cosine similarity calculations and index operations.
 * It involves creating vectors with random values, constructing an index, and verifying that the index operations
 * like search work correctly with respect to the cosine similarity metric.
 *
 * @param collection_size Number of vectors to be included in the test.
 * @param dimensions Number of dimensions each vector should have.
 * @tparam scalar_at Data type of the elements in the vectors.
 * @tparam key_at Data type used for the keys in the index.
 * @tparam slot_at Data type used for slots in the index.
 */
template <typename scalar_at, typename key_at, typename slot_at> //
void test_cosine(std::size_t collection_size, std::size_t dimensions) {

    using scalar_t = scalar_at;
    using vector_key_t = key_at;
    using slot_t = slot_at;

    using index_typed_t = index_gt<float, vector_key_t, slot_t>;
    using member_cref_t = typename index_typed_t::member_cref_t;
    using member_citerator_t = typename index_typed_t::member_citerator_t;

    using vector_of_vectors_t = std::vector<std::vector<scalar_at>>;
    vector_of_vectors_t vector_of_vectors(collection_size);
    for (auto& vector : vector_of_vectors) {
        vector.resize(dimensions);
        std::generate(vector.begin(), vector.end(), [=] { return float(std::rand()) / float(RAND_MAX); });
    }

    struct metric_t {
        vector_of_vectors_t const* vector_of_vectors_ptr = nullptr;
        std::size_t dimensions = 0;

        scalar_t const* row(std::size_t i) const noexcept { return (*vector_of_vectors_ptr)[i].data(); }

        float operator()(member_cref_t const& a, member_cref_t const& b) const {
            return metric_cos_gt<scalar_t, float>{}(row(get_slot(b)), row(get_slot(a)), dimensions);
        }
        float operator()(scalar_t const* some_vector, member_cref_t const& member) const {
            return metric_cos_gt<scalar_t, float>{}(some_vector, row(get_slot(member)), dimensions);
        }
        float operator()(member_citerator_t const& a, member_citerator_t const& b) const {
            return metric_cos_gt<scalar_t, float>{}(row(get_slot(b)), row(get_slot(a)), dimensions);
        }
        float operator()(scalar_t const* some_vector, member_citerator_t const& member) const {
            return metric_cos_gt<scalar_t, float>{}(some_vector, row(get_slot(member)), dimensions);
        }
    };

    // Template:
    auto run_templated = [&](std::size_t connectivity) {
        std::printf("-- templates with connectivity %zu \n", connectivity);
        metric_t metric{&vector_of_vectors, dimensions};
        index_config_t config(connectivity);

        // Toy example
        if (vector_of_vectors.size() >= 3) {
            aligned_wrapper_gt<index_typed_t> aligned_index(config);
            test_minimal_three_vectors<false, index_typed_t>( //
                *aligned_index.index,                         //
                42, vector_of_vectors[0],                     //
                43, vector_of_vectors[1],                     //
                44, vector_of_vectors[2], metric);
        }
        // Larger collection
        {
            aligned_wrapper_gt<index_typed_t> aligned_index(config);
            test_collection<false, index_typed_t>(*aligned_index.index, 42, vector_of_vectors, metric);
        }
    };
    for (std::size_t connectivity : {3, 13, 50})
        run_templated(connectivity);

    // Type-punned:
    auto run_punned = [&](bool multi, bool enable_key_lookups, std::size_t connectivity) {
        std::printf("-- punned with connectivity %zu, multi: %s, lookups: %s \n", connectivity, multi ? "yes" : "no",
                    enable_key_lookups ? "yes" : "no");
        using index_t = index_dense_gt<vector_key_t, slot_t>;
        using index_result_t = typename index_t::state_result_t;
        metric_punned_t metric(dimensions, metric_kind_t::cos_k, scalar_kind<scalar_at>());
        index_dense_config_t config(connectivity);
        config.multi = multi;
        config.enable_key_lookups = enable_key_lookups;

        // Toy example
        if (vector_of_vectors.size() >= 3) {
            index_result_t index_result = index_t::make(metric, config);
            test_minimal_three_vectors<true>( //
                index_result.index,           //
                42, vector_of_vectors[0],     //
                43, vector_of_vectors[1],     //
                44, vector_of_vectors[2]);
        }
        if (vector_of_vectors.size() >= 3 && enable_key_lookups) {
            index_result_t index_result = index_t::make(metric, config);
            test_punned_add_remove_vector( //
                index_result.index,        //
                vector_of_vectors[0],      //
                vector_of_vectors[1]);
        }
        // Larger collection
        {
            index_result_t index_result = index_t::make(metric, config);
            test_collection<true>(index_result.index, 42, vector_of_vectors);
        }

        // Try running benchmarks with a different number of threads
        for (std::size_t threads : {
                 static_cast<std::size_t>(1),
                 // TODO: Multithreaded updates should word differently and may involve a search first
                 //  static_cast<std::size_t>(2),
                 //  static_cast<std::size_t>(std::thread::hardware_concurrency()),
                 //  static_cast<std::size_t>(std::thread::hardware_concurrency() * 4),
                 //  static_cast<std::size_t>(vector_of_vectors.size()),
             }) {
            index_result_t index_result = index_t::make(metric, config);
            index_t& index = index_result.index;
            test_punned_concurrent_updates(index, 42, vector_of_vectors, threads);
        }
    };

    for (bool multi : {false, true})
        for (bool enable_key_lookups : {true, false})
            for (std::size_t connectivity : {3, 13, 50})
                run_punned(multi, enable_key_lookups, connectivity);
}

/**
 * Tests the functionality of the Tanimoto coefficient calculation and indexing.
 *
 * Initializes a dense index configured for Tanimoto similarity and fills it with randomly generated binary vectors.
 * It performs concurrent additions of these vectors to the index to ensure thread safety and correctness of concurrent
 * operations.
 *
 * @param dimensions Number of dimensions for the binary vectors.
 * @param connectivity The degree of connectivity for the index configuration.
 * @tparam key_at Data type used for the keys in the index.
 * @tparam slot_at Data type used for slots in the index.
 */
template <typename key_at, typename slot_at> void test_tanimoto(std::size_t dimensions, std::size_t connectivity) {

    using vector_key_t = key_at;
    using slot_t = slot_at;

    using index_punned_t = index_dense_gt<vector_key_t, slot_t>;
    std::size_t words = divide_round_up<CHAR_BIT>(dimensions);
    metric_punned_t metric(words, metric_kind_t::tanimoto_k, scalar_kind_t::b1x8_k);
    index_config_t config(connectivity);
    auto index_result = index_punned_t::make(metric, config);
    expect(index_result);
    index_punned_t& index = index_result.index;

    executor_default_t executor;
    std::size_t batch_size = 1000;
    std::vector<b1x8_t> scalars(batch_size * index.scalar_words());
    std::generate(scalars.begin(), scalars.end(), [] { return static_cast<b1x8_t>(std::rand()); });

    index.try_reserve({batch_size + index.size(), executor.size()});
    executor.fixed(batch_size, [&](std::size_t thread, std::size_t task) {
        index.add(task + 25000, scalars.data() + index.scalar_words() * task, thread);
    });
}

/**
 * Performs a unit test on the index with a ridiculous variety of configurations and parameters.
 *
 * This test aims to evaluate the index under extreme conditions, including small and potentially invalid parameters for
 * connectivity, dimensions, and other configurations. It tests both the addition of vectors and their retrieval in
 * these edge cases to ensure stability and error handling.
 *
 * @param dimensions Number of dimensions for the vectors.
 * @param connectivity Index connectivity configuration.
 * @param expansion_add Expansion factor during addition operations.
 * @param expansion_search Expansion factor during search operations.
 * @param count_vectors Number of vectors to add to the index.
 * @param count_wanted Number of results wanted from search operations.
 * @tparam key_at Data type used for the keys in the index.
 * @tparam slot_at Data type used for slots in the index.
 */
template <typename key_at, typename slot_at>
void test_absurd(std::size_t dimensions, std::size_t connectivity, std::size_t expansion_add,
                 std::size_t expansion_search, std::size_t count_vectors, std::size_t count_wanted) {

    using vector_key_t = key_at;
    using slot_t = slot_at;

    using index_punned_t = index_dense_gt<vector_key_t, slot_t>;
    metric_punned_t metric(dimensions, metric_kind_t::cos_k, scalar_kind_t::f32_k);
    index_dense_config_t config(connectivity, expansion_add, expansion_search);
    auto index_result = index_punned_t::make(metric, config);
    expect(index_result);
    index_punned_t& index = index_result.index;

    std::size_t count_max = (std::max)(count_vectors, count_wanted);
    std::size_t needed_scalars = count_max * dimensions;
    std::vector<f32_t> scalars(needed_scalars);
    std::generate(scalars.begin(), scalars.end(), [] { return static_cast<f32_t>(std::rand()); });

    expect(index.try_reserve({count_vectors, count_max}));
    index.change_expansion_add(expansion_add);
    index.change_expansion_search(expansion_search);

    // Parallel construction
    {
        executor_default_t executor(count_vectors);
        executor.fixed(count_vectors, [&](std::size_t thread, std::size_t task) {
            expect(index.add(task + 25000, scalars.data() + index.scalar_words() * task, thread));
        });
    }

    // Parallel search
    {
        executor_default_t executor(count_max);
        executor.fixed(count_max, [&](std::size_t thread, std::size_t task) {
            std::vector<vector_key_t> keys(count_wanted);
            std::vector<f32_t> distances(count_wanted);
            auto results = index.search(scalars.data() + index.scalar_words() * task, count_wanted, thread);
            expect(results);
            auto count_found = results.dump_to(keys.data(), distances.data());
            expect(count_found <= count_wanted);
            if (count_vectors && count_wanted)
                expect(count_found > 0);
        });
    }
}

/**
 * Tests the exact search functionality over a dataset of vectors, @b without constructing the index.
 *
 * Generates a dataset of vectors and performs exact search queries to verify that the search results are correct.
 * This function mainly validates the basic functionality of exact searches using a given similarity metric.
 *
 * @param dataset_count Number of vectors in the dataset.
 * @param queries_count Number of query vectors.
 * @param wanted_count Number of top matches required from each query.
 * @tparam scalar_at Data type of the elements in the vectors.
 */
template <typename scalar_at>
void test_exact_search(std::size_t dataset_count, std::size_t queries_count, std::size_t wanted_count) {
    std::size_t dimensions = 32;
    metric_punned_t metric(dimensions, metric_kind_t::cos_k, scalar_kind<scalar_at>());

    std::random_device seed_source;
    std::mt19937 generator(seed_source());
    std::uniform_real_distribution<> distribution(0.0, 1.0); // ! We can't pass `scalar_at` to the distribution
    std::vector<scalar_at> dataset(dataset_count * dimensions);
    std::generate(dataset.begin(), dataset.end(), [&] { return static_cast<scalar_at>(distribution(generator)); });

    exact_search_t search;
    auto results = search(                                                            //
        (byte_t const*)dataset.data(), dataset_count, dimensions * sizeof(scalar_at), //
        (byte_t const*)dataset.data(), queries_count, dimensions * sizeof(scalar_at), //
        wanted_count, metric);

    for (std::size_t i = 0; i < results.size(); ++i)
        assert(results.at(i)[0].offset == i); // Validate the top match
}

/**
 * Tests handling of variable length sets (group of sorted unique integers), as opposed to @b equi-dimensional vectors.
 *
 * Adds a predefined number of vectors to an index and checks if the size of the index is updated correctly.
 * It serves as a simple verification and showcase of how the same index can be used to handle strings and other types.
 *
 * @param index A reference to the index instance to be tested.
 * @tparam index_at Type of the index being tested.
 */
template <typename key_at, typename slot_at>
void test_sets(std::size_t collection_size, std::size_t min_set_length, std::size_t max_set_length) {

    /// Type of set elements, should support strong ordering
    using set_member_t = std::uint32_t;
    /// Jaccard is a fraction, so let's use a some float
    using set_distance_t = double;

    // Aliases for the index overload
    using vector_key_t = key_at;
    using slot_t = slot_at;
    using index_t = index_gt<set_distance_t, vector_key_t, slot_t>;

    // Let's allocate some data for indexing
    using set_view_t = span_gt<set_member_t const>;
    using sets_t = std::vector<std::vector<set_member_t>>;
    sets_t sets(collection_size);
    for (auto& set : sets) {
        std::size_t set_size = min_set_length + std::rand() % (max_set_length - min_set_length);
        set.resize(set_size);
        std::size_t upper_bound = (max_set_length - min_set_length) * 3;
        std::generate(set.begin(), set.end(), [=] { return static_cast<set_member_t>(std::rand() % upper_bound); });
        std::sort(set.begin(), set.end());
    }

    // Wrap the data into a proxy object
    struct metric_t {
        using member_cref_t = typename index_t::member_cref_t;
        using member_citerator_t = typename index_t::member_citerator_t;

        sets_t const* sets_ptr = nullptr;

        set_view_t set_at(std::size_t i) const noexcept { return {(*sets_ptr)[i].data(), (*sets_ptr)[i].size()}; }
        set_distance_t between(set_view_t a, set_view_t b) const {
            return metric_jaccard_gt<set_member_t, set_distance_t>{}(a.data(), b.data(), a.size(), b.size());
        }

        set_distance_t operator()(member_cref_t const& a, member_cref_t const& b) const {
            return between(set_at(get_slot(b)), set_at(get_slot(a)));
        }
        set_distance_t operator()(set_view_t some_vector, member_cref_t const& member) const {
            return between(some_vector, set_at(get_slot(member)));
        }
        set_distance_t operator()(member_citerator_t const& a, member_citerator_t const& b) const {
            return between(set_at(get_slot(b)), set_at(get_slot(a)));
        }
        set_distance_t operator()(set_view_t some_vector, member_citerator_t const& member) const {
            return between(some_vector, set_at(get_slot(member)));
        }
    };

    // Perform indexing
    aligned_wrapper_gt<index_t> aligned_index;
    aligned_index.index->reserve(sets.size());
    for (std::size_t i = 0; i < sets.size(); i++)
        aligned_index.index->add(i, set_view_t{sets[i].data(), sets[i].size()}, metric_t{&sets});
    expect(aligned_index.index->size() == sets.size());

    // Perform the search queries
    for (std::size_t i = 0; i < sets.size(); i++) {
        auto results = aligned_index.index->search(set_view_t{sets[i].data(), sets[i].size()}, 5, metric_t{&sets});
        expect(results.size() > 0);
    }
}

/**
 * Tests similarity search over strings using Levenshtein distances
 * implementation from StringZilla.
 *
 * Adds a predefined number of long strings, comparing them.
 *
 * @param index A reference to the index instance to be tested.
 * @tparam index_at Type of the index being tested.
 */
template <typename key_at, typename slot_at> void test_strings() {

    namespace sz = ashvardanian::stringzilla;

    /// Levenshtein distance is an integer
    using levenshtein_distance_t = std::int64_t;

    // Aliases for the index overload
    using vector_key_t = key_at;
    using slot_t = slot_at;
    using index_t = index_gt<levenshtein_distance_t, vector_key_t, slot_t>;

    std::string_view str0 = "ACGTACGTACGTACGTACGTACGTACGTACGTACGT";
    std::string_view str1 = "ACG_ACTC_TAC-TACGTA_GTACACG_ACGT";
    std::string_view str2 = "A_GTACTACGTA-GTAC_TACGTACGTA-GTAGT";
    std::string_view str3 = "GTACGTAGT-ACGTACGACGTACGTACG-TACGTAC";
    std::vector<std::string_view> strings({str0, str1, str2, str3});

    // Wrap the data into a proxy object
    struct metric_t {
        using member_cref_t = typename index_t::member_cref_t;
        using member_citerator_t = typename index_t::member_citerator_t;

        std::vector<std::string_view> const* strings_ptr = nullptr;

        std::string_view str_at(std::size_t i) const noexcept { return (*strings_ptr)[i]; }
        levenshtein_distance_t between(std::string_view a, std::string_view b) const {
            sz::string_view asz{a.data(), a.size()};
            sz::string_view bsz{b.data(), b.size()};
            return sz::edit_distance<char const>(asz, bsz);
        }

        levenshtein_distance_t operator()(member_cref_t const& a, member_cref_t const& b) const {
            return between(str_at(get_slot(b)), str_at(get_slot(a)));
        }
        levenshtein_distance_t operator()(std::string_view some_vector, member_cref_t const& member) const {
            return between(some_vector, str_at(get_slot(member)));
        }
        levenshtein_distance_t operator()(member_citerator_t const& a, member_citerator_t const& b) const {
            return between(str_at(get_slot(*b)), str_at(get_slot(*a)));
        }
        levenshtein_distance_t operator()(std::string_view some_vector, member_citerator_t const& member) const {
            return between(some_vector, str_at(get_slot(*member)));
        }
    };

    // Perform indexing
    aligned_wrapper_gt<index_t> aligned_index;
    aligned_index.index->reserve(strings.size());
    for (std::size_t i = 0; i < strings.size(); i++)
        aligned_index.index->add(i, strings[i], metric_t{&strings});
    expect(aligned_index.index->size() == strings.size());

    // Perform the search queries
    for (std::size_t i = 0; i < strings.size(); i++) {
        auto results = aligned_index.index->search(strings[i], 5, metric_t{&strings});
        expect(results.size() > 0);
    }
}

/**
 *  @brief  Churns a tightly-reserved index, so `slot_lookup_` accumulates tombstones.
 *
 *  Removals leave tombstones that probes must walk past. If they are never reclaimed the
 *  table runs out of empty slots, probes can no longer terminate, and live keys go missing:
 *  `remove` reports nothing removed while `contains` still finds the key. Copying such a
 *  table must rebuild the probe chains, not reproduce the slot layout.
 */
template <typename key_at, typename slot_at> void test_slot_lookup_churn() {
    constexpr std::size_t live_count = 128;
    constexpr std::size_t churn_count = live_count * 8;
    constexpr std::size_t dimensions = 4;

    using index_punned_t = index_dense_gt<key_at, slot_at>;
    metric_punned_t metric(dimensions, metric_kind_t::cos_k);

    std::random_device seed_source;
    std::mt19937 generator(seed_source());
    std::uniform_real_distribution<float> distribution(0.0, 1.0);
    using vector_of_vectors_t = std::vector<std::vector<float>>;

    vector_of_vectors_t vector_of_vectors(live_count + churn_count);
    for (auto& vector : vector_of_vectors) {
        vector.resize(dimensions);
        std::generate(vector.begin(), vector.end(), [&] { return distribution(generator); });
    }

    index_punned_t index = index_punned_t::make(metric);

    // Reserve tightly, so the churn below exhausts the empty slots
    index.reserve(live_count * 3);

    std::vector<key_at> live_keys;
    std::size_t added = 0;
    for (; added < live_count; ++added) {
        index.add(static_cast<key_at>(added), vector_of_vectors[added].data());
        live_keys.push_back(static_cast<key_at>(added));
    }

    // Every iteration frees one slot and immediately reuses it
    for (std::size_t idx = 0; idx < churn_count; ++idx, ++added) {
        key_at victim = live_keys[idx % live_count];
        expect(index.contains(victim));
        expect_eq(index.remove(victim).completed, 1);
        expect(!index.contains(victim));
        index.add(static_cast<key_at>(added), vector_of_vectors[added].data());
        live_keys[idx % live_count] = static_cast<key_at>(added);
    }

    // Every live key stays reachable and the size never drifts
    expect_eq(index.size(), live_count);
    for (key_at key : live_keys)
        expect(index.contains(key));

    // Copying a table that still holds tombstones must not strand live keys
    expect_eq(index.remove(live_keys.back()).completed, 1);
    live_keys.pop_back();

    auto copy_result = index.copy();
    expect(copy_result);
    index_punned_t& copy = copy_result.index;
    expect_eq(copy.size(), live_keys.size());
    for (key_at key : live_keys)
        expect(copy.contains(key));
}

static bool rehash_allocation_fails = false;

/// @brief  `std::allocator<char>` that throws `std::bad_alloc` while `rehash_allocation_fails` is set.
struct failing_char_allocator_t {
    using value_type = char;
    char* allocate(std::size_t length) {
        if (rehash_allocation_fails)
            throw std::bad_alloc();
        return std::allocator<char>{}.allocate(length);
    }
    void deallocate(char* data, std::size_t length) noexcept { std::allocator<char>{}.deallocate(data, length); }
};

/**
 *  @brief  Churns a tightly-reserved hash set while every rehash allocation fails.
 *
 *  `try_reserve` must report the failure instead of terminating, and `try_emplace` must
 *  still place each element in a free or deleted slot, keeping every live entry findable.
 */
void test_slot_lookup_rehash_failure() {
    using set_t = flat_hash_multi_set_gt<std::uint64_t, hash_gt<std::uint64_t>, std::equal_to<std::uint64_t>,
                                         failing_char_allocator_t>;
    constexpr std::uint64_t live_count = 128;
    constexpr std::uint64_t churn_count = live_count * 8;

    set_t set;
    expect(set.try_reserve(live_count));
    for (std::uint64_t key = 0; key < live_count; ++key)
        expect(set.try_emplace(key));

    rehash_allocation_fails = true;
    expect(!set.try_reserve(set.capacity_slots() * 2));

    for (std::uint64_t idx = 0; idx < churn_count; ++idx) {
        expect_eq(set.erase(idx), 1);
        expect(set.try_emplace(live_count + idx));
    }
    expect_eq(set.size(), live_count);
    for (std::uint64_t idx = 0; idx < churn_count; ++idx)
        expect(!set.contains(idx));
    for (std::uint64_t key = churn_count; key < churn_count + live_count; ++key)
        expect(set.contains(key));

    rehash_allocation_fails = false;
    expect_eq(set.erase(churn_count), 1);
    expect(set.try_emplace(churn_count + live_count));
    for (std::uint64_t key = churn_count + 1; key <= churn_count + live_count; ++key)
        expect(set.contains(key));
}

/**
 *  @brief  Tests replacing and updating entries in `index_dense_gt`, to ensure consistency
 *          after modifications.
 */
template <typename key_at, typename slot_at> void test_replacing_update() {

    using vector_key_t = key_at;
    using slot_t = slot_at;

    using index_punned_t = index_dense_gt<vector_key_t, slot_t>;
    metric_punned_t metric(1, metric_kind_t::l2sq_k, scalar_kind_t::f32_k);
    auto index_result = index_punned_t::make(metric);
    expect(index_result);
    index_punned_t& index = index_result.index;

    // Reserve space for 3 entries
    index.try_reserve(3);
    auto as_ptr = [](float v) {
        static float value;
        value = v;
        return &value;
    };

    // Add 3 entries
    index.add(42, as_ptr(1.1f));
    index.add(43, as_ptr(2.1f));
    index.add(44, as_ptr(3.1f));
    expect_eq(index.size(), 3);

    // Assert initial state
    auto initial_search = index.search(as_ptr(1.0f), 3);
    expect_eq(initial_search.size(), 3);
    expect_eq(initial_search[0].member.key, 42);
    expect_eq(initial_search[1].member.key, 43);
    expect_eq(initial_search[2].member.key, 44);

    // Replace the second entry
    index.remove(43);
    index.add(43, as_ptr(2.2f));
    expect_eq(index.size(), 3);

    // Assert state after replacing second entry
    auto post_second_replacement = index.search(as_ptr(1.0f), 3);
    expect_eq(post_second_replacement.size(), 3);
    expect_eq(post_second_replacement[0].member.key, 42);
    expect_eq(post_second_replacement[1].member.key, 43);
    expect_eq(post_second_replacement[2].member.key, 44);

    // Replace the first entry
    index.remove(42);
    index.add(42, as_ptr(1.2f));
    expect_eq(index.size(), 3);

    // Assert state after replacing first entry
    auto final_search = index.search(as_ptr(1.0f), 3, 0);
    expect_eq(final_search.size(), 3);
    expect_eq(final_search[0].member.key, 42);
    expect_eq(final_search[1].member.key, 43);
    expect_eq(final_search[2].member.key, 44);
}

/**
 * Tests the filtered search functionality of the index.
 */
void test_filtered_search() {
    constexpr std::size_t dataset_count = 2048;
    constexpr std::size_t dimensions = 32;
    metric_punned_t metric(dimensions, metric_kind_t::cos_k);

    std::random_device seed_source;
    std::mt19937 generator(seed_source());
    std::uniform_real_distribution<float> distribution(0.0, 1.0);
    using vector_of_vectors_t = std::vector<std::vector<float>>;

    vector_of_vectors_t vector_of_vectors(dataset_count);
    for (auto& vector : vector_of_vectors) {
        vector.resize(dimensions);
        std::generate(vector.begin(), vector.end(), [&] { return distribution(generator); });
    }

    index_dense_t index = index_dense_t::make(metric);
    index.reserve(dataset_count);
    for (std::size_t idx = 0; idx < dataset_count; ++idx)
        index.add(idx, vector_of_vectors[idx].data());
    expect_eq(index.size(), dataset_count);

    {
        auto predicate = [](index_dense_t::key_t key) { return key != 0; };
        auto results = index.filtered_search(vector_of_vectors[0].data(), 10, predicate);
        expect_eq(10u, results.size()); // ! Should not contain 0
        for (std::size_t i = 0; i != results.size(); ++i)
            expect(0 != results[i].member.key);
    }
    {
        auto predicate = [](index_dense_t::key_t) { return false; };
        auto results = index.filtered_search(vector_of_vectors[0].data(), 10, predicate);
        expect_eq(0u, results.size()); // ! Should not contain 0
    }
    {
        auto predicate = [](index_dense_t::key_t key) { return key == 10; };
        auto results = index.filtered_search(vector_of_vectors[0].data(), 10, predicate);
        expect_eq(1u, results.size()); // ! Should not contain 0
        expect_eq(index_dense_t::key_t(10), results[0].member.key);
    }
}

/**
 * Counts live keys that an exhaustive search for their own vector does not return.
 */
template <typename index_at, typename key_at>
std::size_t count_unreachable(index_at& index, std::vector<std::vector<float>> const& vectors,
                              std::vector<key_at> const& live_keys) {
    std::size_t const wanted = index.size();
    std::vector<key_at> keys(wanted);
    std::vector<distance_punned_t> distances(wanted);
    std::size_t unreachable = 0;
    for (key_at key : live_keys) {
        typename index_at::search_result_t search_result =
            index.search(vectors[static_cast<std::size_t>(key)].data(), wanted);
        expect(search_result);
        std::size_t found = search_result.dump_to(keys.data(), distances.data());
        bool found_self = false;
        for (std::size_t r = 0; r != found && !found_self; ++r)
            found_self = keys[r] == key;
        unreachable += !found_self;
    }
    return unreachable;
}

/**
 * `remove()` followed by `add()` reuses the removed node's slot and rewrites it in place.
 * The removed node's old neighbors must be relinked to each other, otherwise the part of
 * the graph that was reachable only through the removed node becomes unreachable.
 *
 * Points on a line make every node link only to its two neighbors on the line, so a
 * single remove + far add cuts the graph in two.
 */
template <typename key_at, typename slot_at> void test_remove_add_line_reachability() {
    using index_t = index_dense_gt<key_at, slot_at>;
    std::size_t const total = 1000;
    std::size_t const far = total + 1;
    std::vector<std::vector<float>> vectors(far + 1);
    for (std::size_t i = 0; i != vectors.size(); ++i)
        vectors[i] = {static_cast<float>(i), 1.0f, 2.0f};
    vectors[far] = {777.2f, 1.0f, 2.0f};

    for (std::size_t removed : {std::size_t(100), std::size_t(500)}) {
        metric_punned_t metric(3, metric_kind_t::l2sq_k, scalar_kind_t::f32_k);
        typename index_t::state_result_t make_result = index_t::make(metric, index_dense_config_t{});
        expect(make_result);
        index_t& index = make_result.index;
        expect(index.try_reserve(far + 1));
        for (std::size_t i = 1; i <= total; ++i)
            expect(index.add(static_cast<key_at>(i), vectors[i].data()));

        expect(index.remove(static_cast<key_at>(removed)));
        expect(index.add(static_cast<key_at>(far), vectors[far].data()));
        expect_eq(index.size(), total);

        std::vector<key_at> live;
        for (std::size_t i = 1; i <= far; ++i)
            if (i != removed)
                live.push_back(static_cast<key_at>(i));
        expect_eq(count_unreachable(index, vectors, live), static_cast<std::size_t>(0));
    }
}

/**
 * Repeated rounds of removing a fraction of the keys and adding new ones, which reuse the
 * removed slots, optionally from several threads. Every live key must stay reachable.
 */
template <typename key_at, typename slot_at>
void test_remove_add_churn_reachability(std::size_t dimensions, std::size_t initial, std::size_t rounds,
                                        std::size_t per_round, std::size_t threads_count) {
    using index_t = index_dense_gt<key_at, slot_at>;
    std::size_t const total = initial + rounds * per_round;
    std::vector<std::vector<float>> vectors(total);
    std::default_random_engine generator(7);
    std::uniform_real_distribution<float> distribution(-1.0f, 1.0f);
    for (auto& vector : vectors) {
        vector.resize(dimensions);
        for (auto& component : vector)
            component = distribution(generator);
    }

    metric_punned_t metric(dimensions, metric_kind_t::l2sq_k, scalar_kind_t::f32_k);
    typename index_t::state_result_t make_result = index_t::make(metric, index_dense_config_t(16));
    expect(make_result);
    index_t& index = make_result.index;
    executor_default_t executor(threads_count);
    expect(index.try_reserve({initial, executor.size()}));
    for (std::size_t i = 0; i != initial; ++i)
        expect(index.add(static_cast<key_at>(i), vectors[i].data()));

    std::vector<key_at> live(initial);
    for (std::size_t i = 0; i != initial; ++i)
        live[i] = static_cast<key_at>(i);
    std::size_t next_key = initial;
    for (std::size_t round = 0; round != rounds; ++round) {
        std::shuffle(live.begin(), live.end(), generator);
        for (std::size_t i = 0; i != per_round; ++i)
            expect(index.remove(live[live.size() - 1 - i]));
        live.resize(live.size() - per_round);
        std::size_t const first_new = next_key;
        executor.fixed(per_round, [&](std::size_t thread, std::size_t task) {
            std::size_t const key = first_new + task;
            expect(index.add(static_cast<key_at>(key), vectors[key].data(), thread));
        });
        for (std::size_t i = 0; i != per_round; ++i)
            live.push_back(static_cast<key_at>(next_key++));
        expect_eq(index.size(), initial);
        expect_eq(count_unreachable(index, vectors, live), static_cast<std::size_t>(0));
    }
}

void test_isolate() {
    constexpr std::size_t dataset_count = 16;
    constexpr std::size_t dimensions = 32;
    metric_punned_t metric(dimensions, metric_kind_t::cos_k);

    std::random_device seed_source;
    std::mt19937 generator(seed_source());
    std::uniform_real_distribution<float> distribution(0.0, 1.0);
    using vector_of_vectors_t = std::vector<std::vector<float>>;

    vector_of_vectors_t vector_of_vectors(dataset_count);
    for (auto& vector : vector_of_vectors) {
        vector.resize(dimensions);
        std::generate(vector.begin(), vector.end(), [&] { return distribution(generator); });
    }

    index_dense_t index = index_dense_t::make(metric);
    index.reserve(dataset_count);
    for (std::size_t idx = 0; idx < dataset_count; ++idx) {
        index.add(idx, vector_of_vectors[idx].data());
    }
    expect_eq(index.size(), dataset_count);

    for (std::size_t idx = 0; idx < dataset_count; ++idx) {
        if (idx % 2 == 0)
            index.remove(idx);
    }

    auto result = index.isolate();
    for (std::size_t idx = 0; idx < dataset_count; ++idx) {
        auto result = index.search(vector_of_vectors[idx].data(), 16);
        expect_eq(result.size(), dataset_count / 2);
    }
}

/**
 *  @brief  Regression test: `compact()` permutes the slots of all members, so the
 *          key-to-slot lookup and the free-slot list must follow the permutation.
 *          Otherwise `get` returns other members' vectors and later `add` calls
 *          overwrite live members.
 */
void test_compact() {
    constexpr std::size_t dataset_count = 256;
    constexpr std::size_t added_count = 64;
    constexpr std::size_t dimensions = 16;
    metric_punned_t metric(dimensions, metric_kind_t::l2sq_k, scalar_kind_t::f32_k);

    std::mt19937 generator(42);
    std::uniform_real_distribution<float> distribution(0.0, 1.0);
    std::vector<std::vector<float>> vectors(dataset_count + added_count, std::vector<float>(dimensions));
    for (auto& vector : vectors)
        std::generate(vector.begin(), vector.end(), [&] { return distribution(generator); });

    index_dense_t index = index_dense_t::make(metric);
    index.reserve(dataset_count + added_count);
    for (std::size_t idx = 0; idx < dataset_count; ++idx)
        expect(index.add(idx, vectors[idx].data()));
    for (std::size_t idx = 0; idx < dataset_count; idx += 3)
        expect(index.remove(idx));
    std::size_t const removed_count = (dataset_count + 2) / 3;

    expect(index.compact());
    expect_eq(index.size(), dataset_count - removed_count);

    // Freed slots must be reused without clobbering live members
    for (std::size_t idx = dataset_count; idx < dataset_count + added_count; ++idx)
        expect(index.add(idx, vectors[idx].data()));
    expect_eq(index.size(), dataset_count - removed_count + added_count);

    std::vector<float> reconstructed(dimensions);
    for (std::size_t idx = 0; idx < dataset_count + added_count; ++idx) {
        bool const removed = idx < dataset_count && idx % 3 == 0;
        expect_eq(index.contains(idx), !removed);
        if (removed)
            continue;
        expect_eq(index.get(idx, reconstructed.data()), std::size_t(1));
        expect(std::equal(reconstructed.begin(), reconstructed.end(), vectors[idx].begin()));
    }
}

static void usearch_write_backtrace(int signal_number) {
    std::fprintf(stderr, "\n[usearch] Fatal signal %d. Back-trace:\n", signal_number);
#if USEARCH_HAS_STD_STACKTRACE
    // C++23 `std::stacktrace` covers every platform the library can reach.
    auto const current_trace = std::stacktrace::current();
    std::size_t frame_index = 0;
    for (auto const& frame : current_trace) {
        std::fprintf(stderr, "  #%2zu %s\n", frame_index, std::to_string(frame).c_str());
        ++frame_index;
    }
#elif defined(_WIN32)
    // Fallback for MSVC stdlibs without `<stacktrace>`: DbgHelp API.
    constexpr USHORT backtrace_depth_limit = 64;
    void* backtrace_frames[backtrace_depth_limit];
    USHORT backtrace_depth = CaptureStackBackTrace(0, backtrace_depth_limit, backtrace_frames, nullptr);
    HANDLE current_process = GetCurrentProcess();
    SymInitialize(current_process, nullptr, TRUE);

    unsigned char symbol_info_buffer[sizeof(SYMBOL_INFO) + 256 * sizeof(char)];
    SYMBOL_INFO* symbol_info = reinterpret_cast<SYMBOL_INFO*>(symbol_info_buffer);
    symbol_info->MaxNameLen = 255;
    symbol_info->SizeOfStruct = sizeof(SYMBOL_INFO);

    for (USHORT frame_index = 0; frame_index < backtrace_depth; ++frame_index) {
        if (SymFromAddr(current_process, reinterpret_cast<DWORD64>(backtrace_frames[frame_index]), 0, symbol_info))
            std::fprintf(stderr, "  #%2u %s + 0x%llx\n", static_cast<unsigned>(frame_index), symbol_info->Name,
                         static_cast<unsigned long long>(reinterpret_cast<DWORD64>(backtrace_frames[frame_index]) -
                                                         symbol_info->Address));
        else
            std::fprintf(stderr, "  #%2u %p\n", static_cast<unsigned>(frame_index), backtrace_frames[frame_index]);
    }
#else
    // Fallback for POSIX stdlibs without `<stacktrace>`: `<execinfo.h>`.
    constexpr int backtrace_depth_limit = 64;
    void* backtrace_frames[backtrace_depth_limit];
    int const backtrace_depth = backtrace(backtrace_frames, backtrace_depth_limit);
    backtrace_symbols_fd(backtrace_frames, backtrace_depth, STDERR_FILENO);
#endif
    std::fflush(stderr);
}

static void usearch_crash_handler(int signal_number) {
    usearch_write_backtrace(signal_number);
    // Restore the default disposition and re-raise so the shell / CI sees the true exit status.
    std::signal(signal_number, SIG_DFL);
    std::raise(signal_number);
}

static void install_crash_handlers() {
    int const fatal_signals[] = {SIGSEGV, SIGABRT, SIGILL, SIGFPE};
    for (int signal_number : fatal_signals)
        std::signal(signal_number, &usearch_crash_handler);
}

/**
 *  @brief  Regression test: `make(metric, config)` must return an index that is
 *          immediately usable - no explicit `reserve` required before `load` /
 *          `view` / `search`. Previously the typed graph's `{0, 0}` thread
 *          limits leaked into `load_from_stream`, leaving `available_threads_`
 *          empty and making the first `search` throw "No available threads to
 *          lock".
 */
void test_load_after_metric_make() {
    std::printf("Testing load and view into a metric-made index\n");

    using index_t = index_dense_gt<std::int64_t, std::uint32_t>;
    std::size_t const dimensions = 32;
    std::size_t const collection = 64;

    std::default_random_engine rng(7);
    std::uniform_real_distribution<float> distribution(-1.f, 1.f);
    std::vector<std::vector<float>> data(collection);
    for (auto& vector : data) {
        vector.resize(dimensions);
        for (auto& value : vector)
            value = distribution(rng);
    }

    metric_punned_t metric(dimensions, metric_kind_t::cos_k, scalar_kind<f32_t>());
    index_dense_config_t config(16);

    // Build an index and persist it to disk.
    index_t::state_result_t built = index_t::make(metric, config);
    expect(built);
    expect(built.index.try_reserve(collection));
    for (std::size_t i = 0; i != collection; ++i)
        expect(built.index.add(static_cast<std::int64_t>(i), data[i].data()));
    char const* path = "tmp_metric_make.usearch";
    expect(built.index.save(path));

    // Load into a fresh, metric-made index that was never explicitly reserved.
    // The first `search` must not throw "No available threads to lock".
    index_t::state_result_t loaded = index_t::make(metric, config);
    expect(loaded);
    expect(loaded.index.load(path));
    expect_eq(loaded.index.size(), collection);
    std::int64_t found[8];
    expect(loaded.index.search(data[0].data(), 5).dump_to(found) != 0);

    // Same check for the memory-mapped `view` path.
    index_t::state_result_t viewed = index_t::make(metric, config);
    expect(viewed);
    expect(viewed.index.view(path));
    expect_eq(viewed.index.size(), collection);
    expect(viewed.index.search(data[0].data(), 5).dump_to(found) != 0);

    std::remove(path);
}

/**
 *  @brief  Feeds `load` and `view` corrupted and truncated index files.
 *
 *  The entry slot and the top level come from the graph header and seed every search, so an
 *  entry slot past the node count, or a top level above the entry node's own, must be rejected.
 *  The matrix dimensions and the node count come from the file itself, so a short file
 *  describes a matrix and a level array that reach past the mapping. Both must be rejected
 *  rather than walked, and a caller-supplied offset past the end must fail the same way.
 */
void test_view_of_corrupted_file() {
    std::printf("Testing load and view of corrupted index files\n");

    using index_t = index_dense_gt<std::int64_t, std::uint32_t>;
    std::size_t const dimensions = 64;
    std::size_t const collection = 2048;
    char const* path = "tmp_truncated.usearch";

    metric_punned_t metric(dimensions, metric_kind_t::l2sq_k, scalar_kind<f32_t>());
    index_t::state_result_t built = index_t::make(metric);
    expect(built);
    expect(built.index.try_reserve(collection));
    std::vector<float> vector(dimensions);
    for (std::size_t i = 0; i != collection; ++i) {
        for (std::size_t d = 0; d != dimensions; ++d)
            vector[d] = static_cast<float>((i * 31 + d) % 997) / 997.f;
        expect(built.index.add(static_cast<std::int64_t>(i), vector.data()));
    }
    expect(built.index.save(path));

    // The graph header follows the 32-bit matrix dimensions, the vectors and the dense head.
    long const header_offset = static_cast<long>(2 * sizeof(std::uint32_t) + collection * dimensions * sizeof(float) +
                                                 sizeof(index_dense_head_buffer_t));
    auto write_header = [&](index_serialized_header_t const& header) {
        std::FILE* file = std::fopen(path, "r+b");
        expect(file != nullptr);
        std::fseek(file, header_offset, SEEK_SET);
        expect(std::fwrite(&header, sizeof(header), 1, file) == 1);
        std::fclose(file);
    };
    index_serialized_header_t original;
    {
        std::FILE* file = std::fopen(path, "rb");
        expect(file != nullptr);
        std::fseek(file, header_offset, SEEK_SET);
        expect(std::fread(&original, sizeof(original), 1, file) == 1);
        std::fclose(file);
    }
    expect_eq(original.size, static_cast<std::uint64_t>(collection));

    // In a valid file the top level is the entry node's level, so one more is just past it.
    index_serialized_header_t corrupted[2] = {original, original};
    corrupted[0].entry_slot = original.size;
    corrupted[1].max_level = original.max_level + 1;
    for (index_serialized_header_t const& header : corrupted) {
        write_header(header);
        index_t::state_result_t loaded = index_t::make(metric);
        expect(loaded);
        serialization_result_t load_result = loaded.index.load(path);
        expect(!load_result);
        load_result.error.release();
        index_t::state_result_t viewed = index_t::make(metric);
        expect(viewed);
        serialization_result_t view_result = viewed.index.view(path);
        expect(!view_result);
        view_result.error.release();
    }
    write_header(original);

    std::vector<char> prefix;
    {
        std::FILE* file = std::fopen(path, "rb");
        expect(file != nullptr);
        std::fseek(file, 0, SEEK_END);
        long const bytes = std::ftell(file);
        std::fseek(file, 0, SEEK_SET);
        prefix.resize(static_cast<std::size_t>(bytes) / 8);
        expect(std::fread(prefix.data(), 1, prefix.size(), file) == prefix.size());
        std::fclose(file);
    }
    {
        std::FILE* file = std::fopen(path, "wb");
        expect(file != nullptr);
        std::fwrite(prefix.data(), 1, prefix.size(), file);
        std::fclose(file);
    }

    index_t::state_result_t viewed = index_t::make(metric);
    expect(viewed);
    serialization_result_t truncated = viewed.index.view(path);
    expect(!truncated);
    truncated.error.release();

    // A caller-supplied offset past the end must fail the same way.
    index_t::state_result_t offset_viewed = index_t::make(metric);
    expect(offset_viewed);
    serialization_result_t beyond = offset_viewed.index.view(memory_mapped_file_t(path), prefix.size() * 4);
    expect(!beyond);
    beyond.error.release();

    std::remove(path);
}

/**
 *  @brief  Regression test: every thread context must draw node levels of its own. Default-seeded, all
 *          contexts drew the same levels and started over after every `reserve`, so every per-level node
 *          count was a multiple of `contexts * steps`, the upper levels too full and the top ones missing.
 */
void test_level_generators() {
    constexpr std::size_t contexts = 16, steps = 16, per_context_step = 64, dimensions = 2;
    metric_punned_t metric(dimensions, metric_kind_t::l2sq_k, scalar_kind_t::f32_k);
    index_dense_t index = index_dense_t::make(metric);

    std::mt19937 generator(42);
    std::uniform_real_distribution<float> distribution(0.0, 1.0);

    std::size_t key = 0;
    for (std::size_t step = 0; step != steps; ++step) {
        expect(index.try_reserve(index_limits_t((step + 1) * contexts * per_context_step, contexts)));
        for (std::size_t idx = 0; idx != contexts * per_context_step; ++idx, ++key) {
            float vector[dimensions] = {distribution(generator), distribution(generator)};
            expect(index.add(key, vector, idx % contexts));
        }
    }
    expect_eq(index.size(), contexts * steps * per_context_step);

    // Independent draws put about 1024 nodes on level 1 and 64 on level 2: almost never multiples of 256.
    bool all_multiples = true;
    for (std::size_t level = 1; level <= index.max_level(); ++level)
        all_multiples = all_multiples && index.stats(level).nodes % (contexts * steps) == 0;
    expect(!all_multiples);
}

int main(int, char**) {
    install_crash_handlers();

    std::printf("Hardware acceleration compiled: %s\n", hardware_acceleration_compiled());
    std::printf("Hardware acceleration available: %s\n", hardware_acceleration_available());

    // Non-default floating-point types may result in many compilation & rounding issues.
    test_uint40();
    test_checked_size_arithmetic();
    test_cosine<f32_t, std::int64_t, uint40_t>(10, 10);
    test_cosine<bf16_t, std::int64_t, uint40_t>(10, 10);
    test_cosine<f16_t, std::int64_t, uint40_t>(10, 10);
    test_cosine<e5m2_t, std::int64_t, uint40_t>(10, 10);
    test_cosine<e4m3_t, std::int64_t, uint40_t>(10, 10);

    // Test plugins, like K-Means clustering.
    {
        std::size_t vectors_count = 1000, centroids_count = 10, dimensions = 256;
        kmeans_clustering_t clustering;
        clustering.max_iterations = 2;
        std::vector<float> vectors(vectors_count * dimensions), centroids(centroids_count * dimensions);
        matrix_slice_gt<float const> vectors_slice(vectors.data(), dimensions, vectors_count);
        matrix_slice_gt<float> centroids_slice(centroids.data(), dimensions, centroids_count);
        std::generate(vectors.begin(), vectors.end(), [] { return float(std::rand()) / float(RAND_MAX); });
        std::vector<std::size_t> assignments(vectors_count);
        std::vector<distance_punned_t> distances(vectors_count);
        auto clustering_result = clustering(vectors_slice, centroids_slice, {assignments.data(), assignments.size()},
                                            {distances.data(), distances.size()});
        expect(clustering_result);
    }

    // Exact search without constructing indexes.
    // Great for validating the distance functions.
    std::printf("Testing exact search\n");
    for (std::size_t dataset_count : {10, 100})
        for (std::size_t queries_count : {1, 10})
            for (std::size_t wanted_count : {1, 5}) {
                test_exact_search<f32_t>(dataset_count, queries_count, wanted_count);
                test_exact_search<bf16_t>(dataset_count, queries_count, wanted_count);
                test_exact_search<f16_t>(dataset_count, queries_count, wanted_count);
                test_exact_search<e5m2_t>(dataset_count, queries_count, wanted_count);
                test_exact_search<e4m3_t>(dataset_count, queries_count, wanted_count);
            }

    // Make sure the initializers and the algorithms can work with inadequately small values.
    // Be warned - this combinatorial explosion of tests produces close to __500'000__ tests!
    std::printf("Testing allowed, but absurd index configs\n");
    for (std::size_t connectivity : {2, 3})   // ! Zero maps to default, one degenerates
        for (std::size_t dimensions : {1, 3}) // ! Zero will raise
            for (std::size_t expansion : {0, 1, 3})
                for (std::size_t count_vectors : {0, 1, 2, 17})
                    for (std::size_t count_wanted : {0, 1, 3, 19}) {
                        test_absurd<std::int64_t, slot32_t>(dimensions, connectivity, expansion, expansion,
                                                            count_vectors, count_wanted);
                        test_absurd<uint40_t, uint40_t>(dimensions, connectivity, expansion, expansion, count_vectors,
                                                        count_wanted);
                    }

    // TODO: Test absurd configs that are banned
    // for (metric_kind_t metric_kind : {metric_kind_t::cos_k, metric_kind_t::unknown_k, metric_kind_t::haversine_k}) {}

    // Test with cosine metric - the most common use case
    std::printf("Testing common cases\n");
    for (std::size_t collection_size : {10, 500})
        for (std::size_t dimensions : {97, 256}) {
            std::printf("- Indexing %zu vectors with cos: <f32_t, std::int64_t, slot32_t> \n", collection_size);
            test_cosine<f32_t, std::int64_t, slot32_t>(collection_size, dimensions);
            std::printf("- Indexing %zu vectors with cos: <f32_t, std::int64_t, uint40_t> \n", collection_size);
            test_cosine<f32_t, std::int64_t, uint40_t>(collection_size, dimensions);
            std::printf("- Indexing %zu vectors with cos: <bf16, std::int64_t, uint40_t> \n", collection_size);
            test_cosine<bf16_t, std::int64_t, uint40_t>(collection_size, dimensions);
            std::printf("- Indexing %zu vectors with cos: <e5m2, std::int64_t, uint40_t> \n", collection_size);
            test_cosine<e5m2_t, std::int64_t, uint40_t>(collection_size, dimensions);
            std::printf("- Indexing %zu vectors with cos: <e4m3, std::int64_t, uint40_t> \n", collection_size);
            test_cosine<e4m3_t, std::int64_t, uint40_t>(collection_size, dimensions);
        }

    // Test with binary vectors
    std::printf("Testing binary vectors\n");
    for (std::size_t connectivity : {3, 13, 50})
        for (std::size_t dimensions : {97, 256})
            test_tanimoto<std::int64_t, slot32_t>(dimensions, connectivity);

    // Beyond dense equi-dimensional vectors - integer sets
    std::printf("Testing sparse vectors, strings, and sets\n");
    for (std::size_t set_size : {1, 100, 1000})
        test_sets<std::int64_t, slot32_t>(set_size, 20, 30);
    test_strings<std::int64_t, slot32_t>();

    std::printf("Testing key lookups under churn\n");
    test_slot_lookup_churn<std::int64_t, std::uint32_t>();
    test_slot_lookup_churn<std::int64_t, uint40_t>();
    std::printf("Testing key lookups when the rehash cannot allocate\n");
    test_slot_lookup_rehash_failure();

    test_filtered_search();

    // `remove()` + `add()` reuses the removed slot; its old neighbors must stay connected.
    std::printf("Testing remove + add reachability\n");
    test_remove_add_line_reachability<std::int64_t, slot32_t>();
    test_remove_add_line_reachability<std::int64_t, uint40_t>();
    test_remove_add_churn_reachability<std::int64_t, slot32_t>(16, 2000, 10, 200, 1);
    if (std::thread::hardware_concurrency() > 1)
        test_remove_add_churn_reachability<std::int64_t, slot32_t>(
            16, 2000, 10, 200, static_cast<std::size_t>(std::thread::hardware_concurrency()));

    test_isolate();
    test_compact();
    test_load_after_metric_make();
    test_view_of_corrupted_file();
    test_level_generators();

    // Regression for USearch #735: concurrent builds must not strand nodes as
    // contained-but-unreachable. Only meaningful with more than one thread, and at
    // a realistic connectivity — at a degenerate connectivity (<= 3) HNSW orphans
    // nodes even single-threaded, which is an algorithmic property, not this race.
    std::printf("Testing concurrent-add reachability (#735)\n");
    if (std::thread::hardware_concurrency() > 1)
        for (std::size_t threads : {static_cast<std::size_t>(4),
                                    static_cast<std::size_t>(std::thread::hardware_concurrency())}) {
            test_concurrent_add_reachability<std::int64_t, slot32_t>(64, 250, threads, 16);
            test_concurrent_add_reachability<std::int64_t, uint40_t>(64, 250, threads, 16);
        }
    return 0;
}
