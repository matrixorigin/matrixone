# USearch for WebAssembly

## Installation

```txt
https://github.com/unum-cloud/usearch
```

## Quickstart

```wolfram

```
