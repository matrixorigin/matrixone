=======
C SDK
=======


.. mdinclude:: ../../c/README.md

.. toctree::
   :hidden:

   reference